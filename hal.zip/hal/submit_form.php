<?php
// Configuration
$db_host = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'login';

// Create connection
$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Process form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category = $_POST["category"];
    $pass_no = $_POST["pass_no"];
    $name = $_POST["name"];
    $aadhar_no = $_POST["aadhar_no"];
    $mobile_no = $_POST["mobile_no"];
    $dob = $_POST["dob"];
    $gender = $_POST["gender"];
    $address = $_POST["address"];
    $permitted_area = $_POST["permitted_area"];
    $pass_requested_by = $_POST["pass_requested_by"];
    $photo = $_FILES["photo"];
    $pass_valid_upto = $_POST["pass_valid_upto"];
    $status = $_POST["status"];
    $pass_issued_date_upto = $_POST["pass_issued_date_upto"];
    $renewed = $_POST["renewed"];
    $pass_received_by = $_POST["pass_received_by"];
    $remarks = $_POST["remarks"];

    // Upload photo
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($photo["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($photo["tmp_name"]);
    if ($check !== false) {
        $uploadOk = 1;
    } else {
        $uploadOk = 0;
    }

    // Check if file already exists
    if (file_exists($target_file)) {
        $uploadOk = 0;
    }

    // Check file size
    if ($photo["size"] > 100000) {
        $uploadOk = 0;
    }

    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "jpeg") {
        $uploadOk = 0;
    }

    // Upload photo
    if ($uploadOk == 1) {
        if (move_uploaded_file($photo["tmp_name"], $target_file)) {
            $photo_url = $target_file;
        } else {
            $photo_url = "";
        }
    } else {
        $photo_url = "";
    }

    // Insert data into database
    $sql = "INSERT INTO data_entry (category, pass_no, name, aadhar_no, mobile_no, dob, gender, address, permitted_area, pass_requested_by, photo, pass_valid_upto, status, pass_issued_date_upto, renewed, pass_received_by, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssssssssss", $category, $pass_no, $name, $aadhar_no, $mobile_no, $dob, $gender, $address, $permitted_area, $pass_requested_by, $photo_url, $pass_valid_upto, $status, $pass_issued_date_upto, $renewed, $pass_received_by, $remarks);
    $stmt->execute();

    // Check if data inserted successfully
    if ($stmt->affected_rows > 0) {
        echo "Data inserted successfully!";
    } else {
        echo "Error inserting data: " . $stmt->error;
    }
}

// Close connection
$conn->close();
?>